/*
    class: CSCI 381/780
    First Name: Trisha
    Last Name: Espejo
    Project 7
    language: JAVA
    project name: Chain Code
    
 */
public class point extends chainCode {
	public int row = -1;
	public int col = -1;
	
}
